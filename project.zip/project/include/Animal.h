#ifndef ANIMAL_H
#define ANIMAL_H

#include <string>

using namespace std;

class Animal {

	public:
		Animal();

		string getBreed();
		void setBreed(string b);

		string getName() const;
		void setName(string n);
	
		string getColour();
		void setColour(string c);
	
		string getDad() const;
		void setDad (string d);
	
		string getMom();
		void setMom (string m);
		


	private:
		string breed;
		string name;
		string colour;
		string dad;
		string mom;
};

#endif