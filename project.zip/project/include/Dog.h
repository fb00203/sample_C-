#include "Animal.h"

class Dog : public Animal {
	
	public:
		Dog();

		string getEar_type();
		void setEar_type(string e_t);

	
		string getHeight();
		void setHeight(string h);


		string getTail_colour();
		void setTail_colour(string t_c);

	private:
		string ear_type;
		string height;
		string tail_colour;

};