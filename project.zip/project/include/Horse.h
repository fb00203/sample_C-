#include "Animal.h"

class Horse : public Animal {
	
	public:
		Horse();

		string getEar_type();
		void setEar_type(string e_t);

	
		string getHeight();
		void setHeight(string h);


		string getTail_colour();
		void setTail_colour(string t_c);

	private:
		string ear_type;
		string height;
		string tail_colour;

};