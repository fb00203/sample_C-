#include "Cat.h"

Cat::Cat(){
	
}

string Cat::getEar_type(){
	return ear_type;
}
void Cat::setEar_type(string e_t){
	ear_type = e_t;
}


string Cat::getHeight(){
	return height;
}
void Cat::setHeight(string h){
	height = h;
}


string Cat::getTail_colour(){
	return tail_colour;
}
void Cat::setTail_colour(string t_c){
	tail_colour = t_c;
}