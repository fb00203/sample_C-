#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>

#include "Dog.h"
#include "Cat.h"
#include "Horse.h"

using namespace std;

void readFromFiles(vector<Dog> &dogs, vector<Cat> &cats, vector<Horse> &horses);

void displayTable (vector<Dog> &dogs, vector<Cat> &cats, vector<Horse> &horses);

void addData(vector<Dog> &dogs, vector<Cat> &cats, vector<Horse> &horses);

string paternalTree (const vector<Dog> &dogs, const vector<Cat> &cats, const vector<Horse> &horses);

int main() {

	vector<Dog> dogs;
	vector<Cat> cats;
	vector<Horse> horses;

	int input;

	readFromFiles(dogs, cats, horses);

    do {
    	cout << endl << endl << endl;
    	cout << "Options available:" << endl;
    	cout << "1. Display Table" << endl;
    	cout << "2. Add animals" << endl;
    	cout << "3. Show parents for a specified animal" << endl << endl;
    	cout << "0. Exit program" << endl;
    	cout << "Please enter your option: ";
    	cin >> input;

    	while(input != 0 && input != 1 && input != 2 && input != 3) {
    		cout << "Option unavailable. Please choose from above." << endl;
    		cin >> input;
    	}
  
    	switch (input) {
    		case 1:  { displayTable(dogs, cats, horses); break;}
    		case 2: { 
    			addData(dogs, cats, horses);
    			dogs.clear();
    			cats.clear();
    			horses.clear();
    			readFromFiles(dogs, cats, horses);
    			break;
    		}
    		case 3: { cout << paternalTree(dogs, cats, horses); }
    	}

    } while(input);

    return 0;
}

void readFromFiles(vector<Dog> &dogs, vector<Cat> &cats, vector<Horse> &horses) {
	// Read file using fstream	
    ifstream infileDogs		("Dogs.csv");
    ifstream infileCats		("Cats.csv");
    ifstream infileHorses	("Horses.csv");
    if (infileDogs.is_open()) { // Test if the Dogs file is accessible
        string line;

        while (getline(infileDogs, line)) { // Read a line until EOF
            stringstream ss(line);
            string item;

            Dog dog;

            getline(ss, item, ',');
            dog.setBreed(item);

            getline(ss, item, ',');
            dog.setName(item);

            getline(ss, item, ',');
            dog.setColour(item);

            getline(ss, item, ',');
            dog.setEar_type(item);

            getline(ss, item, ',');
            dog.setHeight(item);

            getline(ss, item, ',');
            dog.setTail_colour(item);

            getline(ss, item, ',');
            if(item != "") {
            	dog.setDad(item);
            } else {
            	dog.setDad("N/A");
            }

            getline(ss, item, ',');
            if(item == "") {
            	dog.setMom("N/A");
            } else {
            	dog.setMom(item);
            }

            dogs.push_back(dog);
        }
    } else {                // File not opened
        cout << "Error reading Dogs file!" << endl;
    }

    if (infileCats.is_open()) { // Test if the Cats file is accessible
        string line;

        while (getline(infileCats, line)) { // Read a line until EOF
            stringstream ss(line);
            string item;

            Cat cat;

            getline(ss, item, ',');
            cat.setBreed(item);

            getline(ss, item, ',');
            cat.setName(item);

            getline(ss, item, ',');
            cat.setColour(item);

            getline(ss, item, ',');
            cat.setEar_type(item);

            getline(ss, item, ',');
            cat.setHeight(item);

            getline(ss, item, ',');
            cat.setTail_colour(item);
            item = "";

            getline(ss, item, ',');
            if(item != "") {
            	cat.setDad(item);
            } else {
            	cat.setDad("N/A");
            }

            getline(ss, item, ',');
            if(item != "") {
            	cat.setMom(item);
            } else {
            	cat.setMom("N/A");
            }

            cats.push_back(cat);
        }
    } else {                // File not opened
        cout << "Error reading Cats file!" << endl;
    }

    if (infileHorses.is_open()) { // Test if the Horses file is accessible
        string line;

        while (getline(infileHorses, line)) { // Read a line until EOF
            stringstream ss(line);
            string item;

            Horse horse;

            getline(ss, item, ',');
            horse.setBreed(item);

            getline(ss, item, ',');
            horse.setName(item);

            getline(ss, item, ',');
            horse.setColour(item);

            getline(ss, item, ',');
            horse.setEar_type(item);

            getline(ss, item, ',');
            horse.setHeight(item);

            getline(ss, item, ',');
            horse.setTail_colour(item);

            getline(ss, item, ',');

            if(item != "") {
            	horse.setDad(item);
            } else {
            	horse.setDad("N/A");
            }

            getline(ss, item, ',');
            if(item != "") {
            	horse.setMom(item);
            } else {
            	horse.setMom("N/A");
            }

            horses.push_back(horse);
        }
    } else {                // File not opened
        cout << "Error reading Horses file!" << endl;
    }
}

void displayTable (vector<Dog> &dogs, vector<Cat> &cats, vector<Horse> &horses) {
	cout << endl << endl;

	cout << "There are " 
		 << dogs.size() << " dog(s), " 
		 << cats.size() << " cat(s) and  " 
		 << horses.size() << " horse(s) in the inventory, which are: " << endl;

	int x = 12;
	cout << "Name" << setw(x) << "Group" << setw(x) << "Breed" << setw(x)
		 << "Colour" << setw(x+2) << "Ear Type" << setw(x) << "Height" << setw(x+5)
		 << "Tail Colour"  << setw(x) << "Dad"  << setw(x) << "Mom" << endl;

	cout << "-------------------------------------------------------------------------------------------" << endl;

	for(int i = 0; i < dogs.size(); i++) {
		cout << dogs[i].getName() << setw(x) << "Dog" << setw(x) << dogs[i].getBreed() << setw(x)
		 << dogs[i].getColour() << setw(x+2) << dogs[i].getEar_type() << setw(x) << dogs[i].getHeight() << setw(x+5)
		 << dogs[i].getTail_colour()  << setw(x) << dogs[i].getDad()  << setw(x) << dogs[i].getMom() << endl;
	} 
	cout << endl;

	for(int i = 0; i < cats.size(); i++) {
		cout << cats[i].getName() << setw(x) << "Cat" << setw(x) << cats[i].getBreed() << setw(x)
		 << cats[i].getColour() << setw(x+2) << cats[i].getEar_type() << setw(x) << cats[i].getHeight() << setw(x+5)
		 << cats[i].getTail_colour()  << setw(x) << cats[i].getDad()  << setw(x) << cats[i].getMom() << endl;
	}

	cout << endl;

	for(int i = 0; i < horses.size(); i++) {
		cout << horses[i].getName() << setw(x) << "Horse" << setw(x) << horses[i].getBreed() << setw(x)
		 << horses[i].getColour() << setw(x+2) << horses[i].getEar_type() << setw(x) << horses[i].getHeight() << setw(x+5)
		 << horses[i].getTail_colour()  << setw(x) << horses[i].getDad()  << setw(x) << horses[i].getMom() << endl;
	}
}

void addData(vector<Dog> &dogs, vector<Cat> &cats, vector<Horse> &horses) {
	cout<<  endl << endl;

	int input;
	
    cout << "Animals available:" << endl;
    cout << "1. Dog" << endl;
    cout << "2. Cat" << endl;
    cout << "3. Horse" << endl << endl;
    cout << "0. Cancel" << endl;
    cout << "Please enter your option: ";

	cin >> input;
    while(input != 0 && input != 1 && input != 2 && input != 3) {
    	cout << "Option unavailable. Please choose from above." << endl;
    	cin >> input;
    }

	switch (input) {
		case 1: {
			ofstream fileDogs ("Dogs.csv", ios::app);

			if (fileDogs.is_open()) { // Test if the Dogs file is accessible
				
				string dog;

				cout << "Enter dog's breed: ";
				cin >> dog;
				fileDogs << dog << ",";
				dog = "";

				cout << "Enter dog's name: ";
				cin >> dog;
				fileDogs << dog << ",";
				dog = "";

				cout << "Enter dog's colour: ";
				cin >> dog;
				fileDogs << dog << ",";
				dog = "";

				cout << "Enter dog's ear type: ";
				cin >> dog;
				fileDogs << dog << ",";
				dog = "";

				cout << "Enter dog's height: ";
				cin >> dog;
				fileDogs << dog << ",";
				dog = "";

				cout << "Enter dog's tail colour: ";
				cin >> dog;
				fileDogs << dog << ",";
				dog = "";

				cout << "Enter dog's mom name: ";
				cin >> dog;
				fileDogs << dog << ",";
				dog = "";

				cout << "Enter dog's dad name: ";
				cin >> dog;
				fileDogs << dog << '\n';

				fileDogs.close();
			} else {
				cout << "Error writing Dogs file!" << endl;
			} break;
		}

		case 2: {
			ofstream fileCats ("Cats.csv", ios::app);

			if (fileCats.is_open()) { // Test if the Cogs file is accessible
					
				string cat;

				cout << "Enter cat's breed: ";
				cin >> cat;
				fileCats << cat << ",";
				cat = "";

				cout << "Enter cat's name: ";
				cin >> cat;
				fileCats << cat << ",";
				cat = "";

				cout << "Enter cat's colour: ";
				cin >> cat;
				fileCats << cat << ",";
				cat = "";

				cout << "Enter cat's ear type: ";
				cin >> cat;
				fileCats << cat << ",";
				cat = "";

				cout << "Enter cat's height: ";
				cin >> cat;
				fileCats << cat << ",";
				cat = "";

				cout << "Enter cat's tail colour: ";
				cin >> cat;
				cat = "";

				cout << "Enter cat's mom name: ";
				cin >> cat;
				fileCats << cat << ",";
				cat = "";

				cout << "Enter cat's dad name: ";
				cin >> cat;
				fileCats << cat << '\n';

				fileCats.close();
			} else {
				cout << "Error writing Cats file!" << endl;
			} break;
		}

		case 3: {
			ofstream fileHorses ("Horses.csv", ios::app);

			if (fileHorses.is_open()) { // Test if the Horses file is accessible
					
				string horse;

				cout << "Enter horse's breed: ";
				cin >> horse;
				fileHorses << horse << ",";
				horse = "";

				cout << "Enter horse's name: ";
				cin >> horse;
				fileHorses << horse << ",";
				horse = "";

				cout << "Enter horse's colour: ";
				cin >> horse;
				fileHorses << horse << ",";
				horse = "";

				cout << "Enter horse's ear type: ";
				cin >> horse;
				fileHorses << horse << ",";
				horse = "";

				cout << "Enter horse's height: ";
				cin >> horse;
				fileHorses << horse << ",";
				horse = "";

				cout << "Enter horse's tail colour: ";
				cin >> horse;
				fileHorses << horse << ",";
				horse = "";

				cout << "Enter horse's mom name: ";
				cin >> horse;
				fileHorses << horse << ",";
				horse = "";

				cout << "Enter horse's dad name: ";
				cin >> horse;
				fileHorses << horse << '\n';
				horse = "";

			} else {
				cout << "Error writing Horses file!" << endl;
			} break;
		}
	}
}

string paternalTree (const vector<Dog> &dogs, const vector<Cat> &cats, const vector<Horse> &horses) {
	cout << endl << endl;
	string group = "";

	cout << "Enter the first letter of the animal group: ";
	cin >> group;

	while(group != "d" && group != "c" && group != "h" && group != "a") {
		cout << "Group not found. Enter the first letter of the animal group: ";
		cin >> group;
	}

	string name;

	cout << "Enter the the name of the specified one to find its paternal tree: ";
	cin >> name;
	cout << endl;

	if(group == "d" || group == "a") {
		string result = "";
		int found = 0;
		result += "Paternal three of " + name + '\n';
		if(group == "a") {
			result += name + " is found in the dog inventory." + '\n';
		}

		for(int i = 0; i < dogs.size(); i++) {
			if(dogs[i].getName() == name) {
				result +=  name + " <-- ";
				name = dogs[i].getDad();
				i = 0;
				found = 1;
			}
		}

		if(name != "N/A") {
			result += name + " <-- ";
		}
		
		if (group == "d" || found) {
			if(!found) {
				result = name + " was not found in the inventory within the dogs!";
				return result;
			} else {
				result += "[END]";
				return result;
			}			
		}
	} 

	if(group == "c" || group == "a") {
		string result = "";
		int found = 0;
		result += "Paternal three of " + name + '\n';
		if(group == "a") {
			result += name + " is found in the cat inventory." + '\n';
		}

		for(int i = 0; i < cats.size(); i++) {
			if(cats[i].getName() == name) {
				result +=  name + " <-- ";
				name = cats[i].getDad();
				i = 0;
				found = 1;
			}
		}

		if(name != "N/A") {
			result += name + " <-- ";
		}
		
		if (group == "c" || found) {
			if(!found) {
				result = name + " was not found in the inventory within the cats!";
				return result;
			} else {
				result += "[END]";
				return result;
			}			
		}
	} 

	if(group == "h" || group == "a") {
		string result = "";
		int found = 0;
		result += "Paternal three of " + name + '\n';
		if(group == "a") {
			result += name + " is found in the horse inventory." + '\n';
		}

		for(int i = 0; i < horses.size(); i++) {
			if(horses[i].getName() == name) {
				result +=  name + " <-- ";
				name = horses[i].getDad();
				i = 0;
				found = 1;
			}
		}

		if(name != "N/A" ) {
			result += name + " <-- ";
		}
		
		if (group == "h" || found) {
			if(!found) {
				result = name + " was not found in the inventory within the horses!";
				return result;
			} else {
				result += "[END]";
				return result;
			}			
		}
	}

	if(group == "a") {
		return name + " was not found in any inventory!";
	}
}