#include "Horse.h"

Horse::Horse(){

}

string Horse::getEar_type(){
	return ear_type;
}
void Horse::setEar_type(string e_t){
	ear_type = e_t;
}


string Horse::getHeight(){
	return height;
}
void Horse::setHeight(string h){
	height = h;
}


string Horse::getTail_colour(){
	return tail_colour;
}
void Horse::setTail_colour(string t_c){
	tail_colour = t_c;
}