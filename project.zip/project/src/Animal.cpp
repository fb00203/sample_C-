#include "Animal.h"

Animal::Animal()
{
	
}

string Animal::getBreed(){
	return breed;
}
void Animal::setBreed(string b){
	breed = b;
}


string Animal::getName() const{
	return name;
}
void Animal::setName(string n){
	name = n;
}


string Animal::getColour(){
	return colour;
}
void Animal::setColour(string c){
	colour = c;
}


string Animal::getDad() const{
	return dad;
}
void Animal::setDad(string d){
	dad = d;
}


string Animal::getMom(){
	return mom;
}
void Animal::setMom(string m){
	mom = m;
}