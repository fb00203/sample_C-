#include "Dog.h"

Dog::Dog(){
	
}

string Dog::getEar_type(){
	return ear_type;
}
void Dog::setEar_type(string e_t){
	ear_type = e_t;
}


string Dog::getHeight(){
	return height;
}
void Dog::setHeight(string h){
	height = h;
}


string Dog::getTail_colour(){
	return tail_colour;
}
void Dog::setTail_colour(string t_c){
	tail_colour = t_c;
}